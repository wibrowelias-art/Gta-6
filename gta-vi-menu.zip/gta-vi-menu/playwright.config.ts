import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "./tests",
  timeout: 30000,
  use: {
    baseURL: "http://127.0.0.1:4173",
    viewport: { width: 1920, height: 1080 },
    headless: true,
  },
  reporter: "list",
  webServer: {
    command: "rtk proxy npm run preview",
    url: "http://127.0.0.1:4173",
    reuseExistingServer: true,
  },
});
