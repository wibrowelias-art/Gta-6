# Validation — 8 October 2026

Production compilation: **PASS** (`npm run build`, TypeScript + Vite). Installed packages audited with zero reported vulnerabilities at installation.

Chromium production-browser suite: **6/6 PASS**. A subsequent focused test for the final mouse/keyboard focus synchronization change also passed, **1/1**. The final source compiles successfully.

| Area | Evidence |
|---|---|
| Screen routes | Story start/continue, Online character/session/Play, credits, exit cancel/confirm and restart passed |
| Keyboard | Arrow focus, Enter, Escape, volume adjustment and selected-item restoration passed |
| Persistence | English/German preferences and graphics/audio settings survived reload; malformed stored JSON recovered |
| Loading | Natural studio/branding sequence and cinematic countdown reached the continue prompt; arbitrary keyboard continuation passed |
| Assets | All seven active backgrounds decoded at 3840×2160; logo decoded at 807×540 |
| Fullscreen | Browser Fullscreen API enter/exit passed in Chromium |
| Responsive | Menu remained in viewport without horizontal overflow at 1280×720, 1920×1080, 2560×1440, 3840×2160 and 390×844; desktop, settings and phone screenshots reviewed |
| Audio | No AudioContext before input; running after trusted pointer input; master gain rose and faded to/from mute |
| Gamepad | Simulated standard Xbox mapping navigated and confirmed settings, then returned; no physical hardware attached |
| Mixed input | Hovered choice receives focus, Enter opens it, Escape restores selection |

Issues corrected: focus was initially assigned before the entering screen mounted; moving focus ownership into the transition component resolved keyboard/controller selection. Hover now updates actual keyboard focus. Scene filenames were verified visually against their captions. Corrupt numeric volume and dates are sanitized. Local asset preparation has a timeout.

Limitations: no physical PlayStation/Xbox hardware test; no subjective listening test on speakers; no sustained GPU/60-FPS benchmark or Safari/Firefox coverage. Standard mapping, browser autoplay and fullscreen policies vary. Browser UI may consume Escape while fullscreen. 4K display support was validated through browser viewport testing, not a physical 4K display. No gameplay exists.

The test harness starts a production preview to prevent development hot reloads from interrupting timed boot tests. Run `npm run build` before `npm test`. Tests use the user's installed `rtk` command wrapper; on another machine, replace that wrapper in playwright.config.ts with the ordinary npm preview command if RTK is not installed.
