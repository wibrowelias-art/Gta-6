# Asset attribution

All GTA VI artwork, screenshots, logo, characters, game titles and trademarks are owned by Rockstar Games / their respective rightsholders. Downloaded 8 October 2026 from Rockstar's public promotional media pages for this local, noncommercial fan interface study. Public download availability does not confer a general commercial reuse or redistribution license. This project is unaffiliated with Rockstar Games and Take-Two Interactive.

Official galleries:
- https://www.rockstargames.com/VI/media/artwork-wallpapers
- https://www.rockstargames.com/VI/media/screenshots

| Local asset | Official asset |
|---|---|
| characters.jpg | Jason and Lucia 01 landscape, 3840×2160 |
| couple.jpg | Jason and Lucia 02 landscape, 3840×2160 |
| beach-art.jpg | Jason and Lucia Beach landscape, 3840×2160 (included optional alternate) |
| beach.jpg | Vice City 05, 3840×2160 |
| city.jpg | Vice City 03, 3840×2160 |
| keys.jpg | Leonida Keys 01, 3840×2160 |
| sunset.jpg | Vice City 01, 3840×2160 |
| night.jpg | Vice City 06, 3840×2160 |
| logo.png | Official website GTA VI logo, 807×540 |

Exact direct source URLs are retained in `public/assets/sources.json` and accessible from Credits. Images are stored locally, not hotlinked at runtime. Source files are unmodified; display crops, gradients and camera transforms are applied in CSS.

Ambient audio and sound effects are original procedural Web Audio synthesis authored for this prototype; no external recordings or samples. The grain texture is a procedural SVG filter. Typography uses installed system fonts (Impact, Arial, Georgia); no font files are distributed. Interface icons: Lucide, ISC license, installed through `lucide-react`. React, Vite, TypeScript, Motion and Tailwind retain their respective package licenses in node_modules.
