# Leonida — GTA VI Cinematic Menu Concept

A standalone, noncommercial fan-made interface study. **This is not GTA VI, a leaked menu, or a playable game.** No Rockstar account, server connection or online gameplay is involved.

## Run on Windows

Requires Node.js 22.12+ (or supported Node 20.19+) and a current Edge/Chrome browser.

```powershell
cd C:\Users\elias\Videos\Captures\gta-vi-menu
npm install
npm run dev
```

Open http://127.0.0.1:5173. Use the bottom-right **Fullscreen** control, press **F**, or press browser **F11**. Escape can leave browser fullscreen before returning through a menu, depending on the browser. F11 works when embedded preview fullscreen is unavailable. Exit returns to the startup screen; normal browser tabs cannot close themselves.

```powershell
npm run build
npm run preview
```

The production preview uses http://127.0.0.1:4173. `dist/` is the complete built app; serve it through HTTP rather than opening index.html as a file. All imagery and runtime dependencies are local. Only the optional Credits links navigate externally. No analytics, CDN fonts, remote audio or server API calls are used.

## Experience

- Black → independent studio introduction → GTA VI logo reveal → atmospheric loading sequence → continue prompt → main menu.
- Seven 4K artwork/location scenes, gentle camera movement, parallax, crossfades, gradient shading, optional grain.
- Story: Start creates/replaces a **fictional local concept save**; Continue revisits its cinematic chapter. Neither launches gameplay.
- Online: select a fictional character and session style; Play Online explains that gameplay is unavailable.
- Settings: graphics performance preset, grain, volume/mute, reduced motion, cinematic duration, gamepad prompts, swapped face buttons, stick deadzone, fullscreen and English/German interface.
- Credits and source links; exit/restart flow.
- Original synthesized ambient chord and navigation tones. No copyrighted soundtrack recordings.

Audio starts only after a keyboard or pointer gesture, respecting browser autoplay restrictions. A controller alone may not unlock audio in some browsers; click once or press Enter. Audio fades on volume/mute changes and suspends while the tab is hidden. The cinematic hold is explicitly labelled a preview countdown, never fake system progress. Actual local image preparation is shown separately.

## Controls

| Action | Keyboard / mouse | Standard gamepad |
|---|---|---|
| Focus | Up/Down or Tab/Shift+Tab; hover main items | D-pad or left stick |
| Confirm | Enter or click | Cross / A (swappable) |
| Back | Escape or Back control | Circle / B (swappable) |
| Adjust setting | Click or Left/Right; volume supports both directions | Left/Right or confirm |
| Fullscreen | F or footer control | Focus Fullscreen and confirm |
| Mute | M or footer control | Focus audio and confirm |

On choice rows, either horizontal direction advances the choice; volume moves in the requested direction. Every interactive menu control participates in focus navigation, including footer actions and credits links. Connect an Xbox/PlayStation controller and press a face button to expose it to the browser. Only standard-mapped devices are supported; USB is the most predictable option. No physical controller was available during validation; simulated standard mapping was tested.

## Configuration and source

`src/config.ts` defines scene order/files/labels, intro length, crossfade timing, scene duration, loading duration and defaults. `src/AudioManager.ts` defines synthesized sound. All requested components have their own files under `src/`. `App.tsx` connects the screen state machine and input handling. Tailwind CSS 4 is compiled through its Vite plugin; bespoke CSS provides the cinematic layout, using system fonts to avoid distributing proprietary typefaces.

Preferences use `vi-settings` and the fictional save uses `vi-save` in browser localStorage. Corrupt JSON falls back safely. Storage failures are reported and current-session behavior still works. Online selections are intentionally session-only. Clear those two keys to reset. Motion reduction defaults to your OS preference on first use and can be overridden. Performance mode disables grain and camera movement.

## Validation

Build first; the tests start the production preview automatically (the local RTK command wrapper is used in the test configuration):

```powershell
npx playwright install chromium
npm run build
npm test
```

Tests cover screen paths, keyboard navigation, saved settings/language, story save, boot timing, local image decoding, fullscreen, responsive viewports (720p, 1080p, 1440p, 4K, phone), audio lifecycle and simulated gamepad input. Screenshots are written to `test-results/`. See `TESTING.md` for final results and limitations.

See `RESEARCH.md` for design evidence and the distinction between official references and invented UI. See `ASSET_ATTRIBUTION.md` and `public/assets/sources.json` for asset provenance. `node scripts/download-assets.mjs` restores the exact recorded assets when their official URLs remain available.
