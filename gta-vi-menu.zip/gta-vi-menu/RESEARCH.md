# Research and visual direction

Research date: 8 October 2026. This is an independent, noncommercial interface study, not an official or leaked menu.

## Official references

- [GTA VI](https://www.rockstargames.com/VI): official branding, Jason and Lucia, Vice City and Leonida. The promotional presentation emphasizes character illustration, tropical daylight and cinematic location photography. This project does not reproduce or predict game systems.
- [Artwork and wallpapers](https://www.rockstargames.com/VI/media/artwork-wallpapers): the public download gallery supplies character compositions and landscape variants. Locally downloaded landscape assets are 3840×2160. Pink, lavender, mint, warm cream and silhouetted palms guide the palette. Keep faces clear by placing text on a dark left gradient.
- [Screenshots](https://www.rockstargames.com/VI/media/screenshots): coastal towers, beaches, tropical islands and night scenes inform the rotating environment sequence. Exact downloaded URLs are recorded in public/assets/sources.json.
- [GTAV settings](https://support.rockstargames.com/articles/1FKIriVNBHL72WZ0hrVT8u/adjusting-settings-within-gtav): settings are accessible in Story and Online through a pause-menu settings tab; categories include controls, audio, camera and display. Borrow accessible categories and predictable back behavior, not an alleged VI layout.
- [GTAV PC controls](https://www.rockstargames.com/newswire/article/51974aa3a724o2/rockstar-game-tips-tailoring-your-settings-and-controls-in): Escape pauses when no menu is open; back navigation is consistent. This prototype uses Escape to return.
- [RDR2 Quick Tips](https://www.rockstargames.com/newswire/article/25o2411817k8k7/Red-Dead-Redemption-2-Quick-Tips): the page was reachable but its article body was not extractable. No detailed RDR2 interaction claim is inferred from that result. The sparse vertical list and photographic staging here are original design decisions informed by the broad cinematic genre.
- [PlayStation navigation](https://www.playstation.com/en-us/support/hardware/ps5-console-users-guide/): directional focus, Cross select and Circle back support a legible console interaction model. The standard Gamepad mapping uses buttons 0/1, with configurable swap and stick deadzone.

## Original concept decisions

The intro studio monogram, left-aligned menu, story chapter, fictional save, Online lobby, session and character selections, ambient composition and all transition timings are invented for this fan prototype. None is confirmed GTA VI UI. No Rockstar services or gameplay are available.

Large cream condensed headings sit over dark aubergine shadows; a thin salmon selection rule replaces boxed web navigation. A small location caption balances the empty side of the frame. Images move slowly using compositor transforms; crossfades overlap without horizontal sliding. A 6.5-second boot gives way to a configurable cinematic hold. Actual asset preparation is reported separately; no artificial percentage is described as system work.

The official site's proprietary Art Deco webfonts were observed but are not copied. Local system Impact/Arial Narrow fallbacks provide condensed display lettering without shipping proprietary fonts. The official logo is stored locally. Public download availability is not a blanket commercial redistribution license; all Rockstar imagery and trademarks remain their property.

## Implementation references

- [Vite](https://vite.dev/guide/): local development and production bundling.
- [Motion for React](https://motion.dev/docs/react): opacity and transform transitions, reduced-motion handling.
- [Gamepad API](https://developer.mozilla.org/en-US/docs/Web/API/Gamepad_API/Using_the_Gamepad_API): poll connected standard-mapped controllers, use edge detection and held-direction repeat. Hardware mappings can vary.

Performance choices: two scene layers during crossfade, no animation-driven React updates at frame rate, pointer parallax via CSS custom properties, original Web Audio oscillators, and disabling ambient work while hidden. Hardware-dependent 60 FPS is a target, not a benchmark claim.
